const button = document.querySelector("button");

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const recognition = new SpeechRecognition();

recognition.onstart = function () {
    console.log("TEst");
}

recognition.onresult = function (event) {
    console.log(event);
    const spokenwords = event.results[0][0].transcript;
    console.log("Spoken words are " + spokenwords);
    computerSpeech(spokenwords);
};

button.addEventListener("click", () => {
    recognition.start();
});

function computerSpeech(words) {
    const speech = new SpeechSynthesisUtterance();
    speech.lang = "en-US";
    speech.pitch = 0.9;
    speech.volume = 1;
    speech.rate = 1;
    speech.text = words;
    determineWords(speech, words);
    window.speechSynthesis.speak(speech);

}

function determineWords(speech, words) {
    if (words.includes("how r u") || words.includes("how are u")) {
        speech.text = "thanks master, I am fine"
    }
    if (words.includes("who am I")) {
        speech.text = "you are my master"
    }
}